//   // Initialize the dashboard when DOM is loaded
//   document.addEventListener('DOMContentLoaded', ClientDashboard.init);
document.addEventListener('DOMContentLoaded', function() {
  // Tab switching functionality
  const tabs = document.querySelectorAll('.dashboard-nav li');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabs.forEach(tab => {
      tab.addEventListener('click', function() {
          // Remove active class from all tabs and contents
          tabs.forEach(t => t.classList.remove('active'));
          tabContents.forEach(c => c.classList.remove('active'));
          
          // Add active class to clicked tab and corresponding content
          this.classList.add('active');
          const tabId = this.getAttribute('data-tab') + '-tab';
          document.getElementById(tabId).classList.add('active');
      });
  });
  
  // Logout button
  document.getElementById('logout-btn').addEventListener('click', function() {
      alert('Logging out...');
      // In a real app, this would redirect to logout endpoint
  });
  
  // Populate recent activity
  const activities = [
      { action: 'Project "E-commerce Website" posted', time: '2 hours ago' },
      { action: 'Received 3 proposals for "Logo Design"', time: '1 day ago' },
      { action: 'Hired freelancer for "Mobile App Development"', time: '3 days ago' },
      { action: 'Project "Content Writing" completed', time: '1 week ago' },
      { action: 'Left feedback for "UI/UX Design" project', time: '2 weeks ago' }
  ];
  
  const activityList = document.getElementById('activity-list');
  activities.forEach(activity => {
      const li = document.createElement('li');
      li.innerHTML = `<span>${activity.action}</span><span class="time">${activity.time}</span>`;
      activityList.appendChild(li);
  });
  
  // Dummy projects data
  const dummyProjects = [
      {
          id: 1,
          title: 'E-commerce Website Development',
          category: 'web-dev',
          description: 'Need a full e-commerce website with product listings, cart functionality, and payment processing.',
          skills: ['HTML', 'CSS', 'JavaScript', 'React', 'Node.js'],
          budget: 2500,
          posted: '3 days ago',
          image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
      },
      {
          id: 2,
          title: 'Mobile App UI/UX Design',
          category: 'design',
          description: 'Looking for a designer to create modern UI/UX for a fitness tracking mobile application.',
          skills: ['UI Design', 'UX Design', 'Figma', 'Adobe XD'],
          budget: 1200,
          posted: '1 day ago',
          image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
      },
      {
          id: 3,
          title: 'Content Writing for Tech Blog',
          category: 'writing',
          description: 'Need weekly articles about emerging technologies, AI, and software development trends.',
          skills: ['Content Writing', 'Technical Writing', 'SEO'],
          budget: 800,
          posted: '5 days ago',
          image: 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
      },
      {
          id: 4,
          title: 'Social Media Marketing Campaign',
          category: 'marketing',
          description: 'Looking for a marketing specialist to run a 3-month campaign across Facebook and Instagram.',
          skills: ['Social Media', 'Digital Marketing', 'Facebook Ads'],
          budget: 3000,
          posted: '2 days ago',
          image: 'https://images.unsplash.com/photo-1579869847557-1f67382cc158?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
      },
      {
          id: 5,
          title: 'iOS App Development',
          category: 'mobile-dev',
          description: 'Need an experienced iOS developer to build a productivity app with Swift.',
          skills: ['Swift', 'iOS', 'Xcode', 'Firebase'],
          budget: 4500,
          posted: '1 week ago',
          image: 'https://images.unsplash.com/photo-1519219788971-8d9797e0928e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
      },
      {
          id: 6,
          title: 'WordPress Website Redesign',
          category: 'web-dev',
          description: 'Looking to redesign our existing WordPress site with a modern look and better performance.',
          skills: ['WordPress', 'PHP', 'CSS', 'Elementor'],
          budget: 1500,
          posted: '4 days ago',
          image: 'https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
      },
      {
          id: 7,
          title: 'Android App Bug Fixes',
          category: 'mobile-dev',
          description: 'Need an Android developer to fix several bugs in our existing application.',
          skills: ['Java', 'Android', 'Kotlin', 'Firebase'],
          budget: 750,
          posted: 'Just now',
          image: 'https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
      },
      {
          id: 8,
          title: 'Logo and Brand Identity',
          category: 'design',
          description: 'Looking for a designer to create a logo and basic brand identity guidelines.',
          skills: ['Logo Design', 'Branding', 'Illustrator'],
          budget: 500,
          posted: '3 days ago',
          image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
      }
  ];
  
  // Populate browse projects
  const browseProjectsContainer = document.getElementById('browse-projects');
  dummyProjects.forEach(project => {
      browseProjectsContainer.appendChild(createProjectCard(project));
  });
  
  // Search functionality
  document.getElementById('search-btn').addEventListener('click', function() {
      const searchTerm = document.getElementById('project-search').value.toLowerCase();
      const category = document.getElementById('category-filter').value;
      const budget = document.getElementById('budget-filter').value;
      
      const results = dummyProjects.filter(project => {
          // Check search term
          const matchesSearch = project.title.toLowerCase().includes(searchTerm) || 
                              project.description.toLowerCase().includes(searchTerm);
          
          // Check category
          const matchesCategory = category === '' || project.category === category;
          
          // Check budget
          let matchesBudget = true;
          if (budget !== '') {
              if (budget === '0-500') {
                  matchesBudget = project.budget <= 500;
              } else if (budget === '500-1000') {
                  matchesBudget = project.budget > 500 && project.budget <= 1000;
              } else if (budget === '1000-5000') {
                  matchesBudget = project.budget > 1000 && project.budget <= 5000;
              } else if (budget === '5000+') {
                  matchesBudget = project.budget > 5000;
              }
          }
          
          return matchesSearch && matchesCategory && matchesBudget;
      });
      
      // Display results
      const resultsContainer = document.getElementById('search-results');
      resultsContainer.innerHTML = '';
      
      if (results.length === 0) {
          resultsContainer.innerHTML = '<p>No projects found matching your criteria.</p>';
      } else {
          results.forEach(project => {
              resultsContainer.appendChild(createProjectCard(project));
          });
      }
  });
  
  // New project form submission
  document.getElementById('new-project-form').addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Get form values
      const title = document.getElementById('project-title').value;
      const category = document.getElementById('project-category').value;
      const description = document.getElementById('project-description').value;
      const skills = document.getElementById('project-skills').value;
      const budget = document.getElementById('project-budget').value;
      const deadline = document.getElementById('project-deadline').value;
      
      // In a real app, this would send to the server
      alert(`Project "${title}" submitted successfully!`);
      
      // Reset form
      this.reset();
  });
  
  // Populate conversations
  const conversations = [
      { id: 1, name: 'Alex Johnson (Web Developer)', lastMessage: 'I can start on Monday', time: '2 hours ago', unread: true },
      { id: 2, name: 'Sarah Miller (Graphic Designer)', lastMessage: 'Here are the logo concepts', time: '1 day ago', unread: false },
      { id: 3, name: 'David Kim (SEO Specialist)', lastMessage: 'Your website audit is ready', time: '3 days ago', unread: false },
      { id: 4, name: 'Emma Wilson (Content Writer)', lastMessage: 'The article is submitted', time: '1 week ago', unread: false }
  ];
  
  const conversationsList = document.getElementById('conversations');
  conversations.forEach(conv => {
      const li = document.createElement('li');
      li.innerHTML = `
          <h4>${conv.name}</h4>
          <p>${conv.lastMessage}</p>
          <span class="time">${conv.time}</span>
          ${conv.unread ? '<span class="unread-dot"></span>' : ''}
      `;
      li.addEventListener('click', function() {
          // In a real app, this would load the conversation
          document.getElementById('current-conversation').textContent = conv.name;
          loadDummyMessages();
      });
      conversationsList.appendChild(li);
  });
  
  // Helper function to create project cards
  function createProjectCard(project) {
      const card = document.createElement('div');
      card.className = 'project-card';
      card.innerHTML = `
          <img src="${project.image}" alt="${project.title}">
          <div class="project-card-content">
              <h3>${project.title}</h3>
              <p>${project.description}</p>
              <div class="skills">
                  ${project.skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
              </div>
              <div class="project-card-footer">
                  <span class="budget">$${project.budget}</span>
                  <button class="view-btn">View Details</button>
              </div>
          </div>
      `;
      
      // Add click event to view button
      card.querySelector('.view-btn').addEventListener('click', function() {
          alert(`Viewing details for: ${project.title}`);
      });
      
      return card;
  }
  
  // Helper function to load dummy messages
  function loadDummyMessages() {
      const messages = [
          { text: 'Hello, I\'m interested in your project. Can we discuss the details?', sender: 'freelancer', time: '10:30 AM' },
          { text: 'Hi! Yes, of course. What would you like to know?', sender: 'client', time: '10:35 AM' },
          { text: 'I wanted to ask about the timeline. When do you need this completed by?', sender: 'freelancer', time: '10:36 AM' },
          { text: 'Ideally within 4 weeks. Is that feasible for you?', sender: 'client', time: '10:40 AM' },
          { text: 'Yes, that should be possible. I can send you a proposal with milestones.', sender: 'freelancer', time: '10:42 AM' }
      ];
      
      const messageThread = document.getElementById('message-thread');
      messageThread.innerHTML = '';
      
      messages.forEach(msg => {
          const messageDiv = document.createElement('div');
          messageDiv.className = `message ${msg.sender === 'client' ? 'sent' : 'received'}`;
          messageDiv.innerHTML = `
              <p>${msg.text}</p>
              <span class="message-time">${msg.time}</span>
          `;
          messageThread.appendChild(messageDiv);
      });
      
      // Scroll to bottom
      messageThread.scrollTop = messageThread.scrollHeight;
  }
});