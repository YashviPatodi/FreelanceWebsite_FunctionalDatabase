// scripts/router.js
class Router {
    constructor() {
        this.routes = {
            'home': { 
                template: '/templates/home.html', 
                script: '/scripts/home.js', 
                title: 'The Met Gig - Home' 
            },
            'about': { 
                template: '/templates/about.html', 
                script: '/scripts/about.js', 
                title: 'About Us' 
            },
            'whatsnew': { 
                template: '/templates/whatsnew.html', 
                script: '/scripts/whatsnew.js', 
                title: "What's New" 
            },
            'contact': { 
                template: '/templates/contact.html', 
                script: '/scripts/contact.js', 
                title: 'Contact Us' 
            },
            'login': { 
                template: '/templates/login.html', 
                script: '/scripts/login.js', 
                title: 'Login' 
            }
        };

        this.init();
    }

    init() {
        // Handle initial load
        window.addEventListener('DOMContentLoaded', () => {
            this.loadRoute();
        });

        // Handle popstate (back/forward navigation)
        window.addEventListener('popstate', () => {
            this.loadRoute();
        });

        // Handle link clicks
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-route]')) {
                e.preventDefault();
                const route = e.target.getAttribute('data-route');
                this.navigateTo(route);
            }
        });
    }

    async loadRoute() {
        const path = window.location.pathname.substring(1) || 'home';
        const routeKey = Object.keys(this.routes).find(key => 
            path.startsWith(key) || (key === 'home' && path === '')
        ) || 'home';
        
        const route = this.routes[routeKey];
        
        try {
            // Load template
            const response = await fetch(route.template);
            if (!response.ok) throw new Error('Template not found');
            const html = await response.text();
            
            // Update app content
            document.getElementById('app').innerHTML = html;
            document.title = route.title;
            
            // Update active link
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('data-route') === routeKey) {
                    link.classList.add('active');
                }
            });
            
            // Load script
            if (route.script) {
                const scriptElement = document.createElement('script');
                scriptElement.src = route.script;
                document.body.appendChild(scriptElement);
            }
        } catch (error) {
            console.error('Error loading route:', error);
            this.navigateTo('home');
        }
    }

    navigateTo(route) {
        window.history.pushState({}, '', `/${route === 'home' ? '' : route}`);
        this.loadRoute();
    }
}

// Initialize router
new Router();