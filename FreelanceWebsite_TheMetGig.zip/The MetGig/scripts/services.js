// document.addEventListener('DOMContentLoaded', function() {
//     // Main categories data
//     const mainCategories = [
//         {
//             id: 'web-dev',
//             title: 'Web & Software Development',
//             description: 'Build your website, web app, or software solution',
//             image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             subcategories: [
//                 { name: 'Web Development', link: '#' },
//                 { name: 'Mobile App Development', link: '#' },
//                 { name: 'Desktop Software', link: '#' },
//                 { name: 'E-commerce Development', link: '#' },
//                 { name: 'CMS Development', link: '#' }
//             ]
//         },
//         {
//             id: 'digital-marketing',
//             title: 'Digital Marketing',
//             description: 'Promote your business online and reach more customers',
//             image: 'https://images.unsplash.com/photo-1579869847557-1f67382cc158?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             subcategories: [
//                 { name: 'SEO Services', link: '#' },
//                 { name: 'Social Media Marketing', link: '#' },
//                 { name: 'Content Marketing', link: '#' },
//                 { name: 'Email Marketing', link: '#' },
//                 { name: 'PPC Advertising', link: '#' }
//             ]
//         },
//         {
//             id: 'creative-design',
//             title: 'Creative & Design',
//             description: 'Bring your ideas to life with stunning designs',
//             image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             subcategories: [
//                 { name: 'Logo & Brand Identity', link: '#' },
//                 { name: 'Graphic Design', link: '#' },
//                 { name: 'UI/UX Design', link: '#' },
//                 { name: 'Illustration', link: '#' },
//                 { name: 'Video Production', link: '#' }
//             ]
//         },
//         {
//             id: 'business-consulting',
//             title: 'Business & Consulting',
//             description: 'Expert advice to grow and manage your business',
//             image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             subcategories: [
//                 { name: 'Business Planning', link: '#' },
//                 { name: 'Financial Consulting', link: '#' },
//                 { name: 'Legal Consulting', link: '#' },
//                 { name: 'HR Consulting', link: '#' },
//                 { name: 'Management Consulting', link: '#' }
//             ]
//         },
//         {
//             id: 'other-services',
//             title: 'Other Services',
//             description: 'Find professionals for any other need you have',
//             image: 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             subcategories: [
//                 { name: 'Writing & Translation', link: '#' },
//                 { name: 'Data Science & Analytics', link: '#' },
//                 { name: 'Engineering & Architecture', link: '#' },
//                 { name: 'Customer Service', link: '#' },
//                 { name: 'Virtual Assistant', link: '#' }
//             ]
//         }
//     ];

//     // Trending services data
//     const trendingServices = [
//         {
//             id: 1,
//             title: 'WordPress Website Development',
//             category: 'web-dev',
//             description: 'I will build a professional WordPress website for your business',
//             seller: {
//                 name: 'Alex Johnson',
//                 avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
//                 rating: 4.9,
//                 reviews: 127
//             },
//             price: 250,
//             deliveryTime: '3 days',
//             image: 'https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             tags: ['WordPress', 'Website', 'Responsive']
//         },
//         {
//             id: 2,
//             title: 'Social Media Marketing Package',
//             category: 'digital-marketing',
//             description: 'Professional social media management for Facebook and Instagram',
//             seller: {
//                 name: 'Sarah Miller',
//                 avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
//                 rating: 4.8,
//                 reviews: 89
//             },
//             price: 180,
//             deliveryTime: '7 days',
//             image: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             tags: ['Social Media', 'Marketing', 'Facebook']
//         },
//         {
//             id: 3,
//             title: 'Logo and Brand Identity Design',
//             category: 'creative-design',
//             description: 'I will design a unique logo and brand identity for your company',
//             seller: {
//                 name: 'David Kim',
//                 avatar: 'https://randomuser.me/api/portraits/men/22.jpg',
//                 rating: 5.0,
//                 reviews: 215
//             },
//             price: 150,
//             deliveryTime: '5 days',
//             image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             tags: ['Logo', 'Branding', 'Identity']
//         },
//         {
//             id: 4,
//             title: 'Business Plan Writing',
//             category: 'business-consulting',
//             description: 'Professional business plan writing service for startups and SMEs',
//             seller: {
//                 name: 'Emma Wilson',
//                 avatar: 'https://randomuser.me/api/portraits/women/65.jpg',
//                 rating: 4.7,
//                 reviews: 56
//             },
//             price: 300,
//             deliveryTime: '10 days',
//             image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             tags: ['Business Plan', 'Startup', 'Consulting']
//         },
//         {
//             id: 5,
//             title: 'SEO Optimization Service',
//             category: 'digital-marketing',
//             description: 'Improve your website ranking with my SEO optimization service',
//             seller: {
//                 name: 'Michael Brown',
//                 avatar: 'https://randomuser.me/api/portraits/men/75.jpg',
//                 rating: 4.9,
//                 reviews: 178
//             },
//             price: 200,
//             deliveryTime: '14 days',
//             image: 'https://images.unsplash.com/photo-1581092921461-39b2f2b8a450?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
//             tags: ['SEO', 'Optimization', 'Google']
//         }
//     ];

//     // Testimonials data
//     const testimonials = [
//         {
//             name: 'Robert Johnson',
//             title: 'CEO, TechStart Inc.',
//             avatar: 'https://randomuser.me/api/portraits/men/46.jpg',
//             text: 'The freelancers I found through this platform helped us build our MVP in record time. The quality of work exceeded our expectations.',
//             rating: 5
//         },
//         {
//             name: 'Jennifer Lee',
//             title: 'Marketing Director, BrightCo',
//             avatar: 'https://randomuser.me/api/portraits/women/63.jpg',
//             text: 'We\'ve hired several digital marketing specialists and each one has delivered exceptional results. This platform saves us so much time and money.',
//             rating: 4
//         },
//         {
//             name: 'Thomas Wilson',
//             title: 'Founder, DesignHub',
//             avatar: 'https://randomuser.me/api/portraits/men/81.jpg',
//             text: 'As a small business owner, having access to top talent on demand has been a game changer. Highly recommended!',
//             rating: 5
//         }
//     ];

//     // DOM Elements
//     const mainCategoriesContainer = document.getElementById('main-categories');
//     const trendingServicesContainer = document.getElementById('trending-services');
//     const testimonialSlider = document.getElementById('testimonial-slider');
//     const prevTestimonialBtn = document.getElementById('prev-testimonial');
//     const nextTestimonialBtn = document.getElementById('next-testimonial');
//     const modal = document.getElementById('service-modal');
//     const modalBody = document.getElementById('modal-body');
//     const closeModal = document.querySelector('.close-modal');

//     // Populate main categories
//     function renderMainCategories() {
//         mainCategoriesContainer.innerHTML = '';
//         mainCategories.forEach(category => {
//             const categoryCard = document.createElement('div');
//             categoryCard.className = 'category-card';
//             categoryCard.innerHTML = `
//                 <img src="${category.image}" alt="${category.title}">
//                 <div class="category-card-content">
//                     <h3>${category.title}</h3>
//                     <p>${category.description}</p>
//                     <button class="view-btn" data-category="${category.id}">Browse Services</button>
//                 </div>
//                 <div class="subcategories">
//                     <h4>Popular Subcategories</h4>
//                     <ul>
//                         ${category.subcategories.map(sub => `<li><a href="${sub.link}">${sub.name}</a></li>`).join('')}
//                     </ul>
//                 </div>
//             `;
//             mainCategoriesContainer.appendChild(categoryCard);
//         });
//     }

//     // Populate trending services
//     function renderTrendingServices() {
//         trendingServicesContainer.innerHTML = '';
//         trendingServices.forEach(service => {
//             const serviceCard = document.createElement('div');
//             serviceCard.className = 'service-card';
//             serviceCard.innerHTML = `
//                 <img src="${service.image}" alt="${service.title}">
//                 <div class="service-card-content">
//                     <h3>${service.title}</h3>
//                     <div class="seller-info">
//                         <img src="${service.seller.avatar}" alt="${service.seller.name}">
//                         <span>${service.seller.name}</span>
//                     </div>
//                     <div class="rating">
//                         ${'★'.repeat(service.seller.rating)}${'☆'.repeat(5 - service.seller.rating)}
//                         <span>(${service.seller.reviews})</span>
//                     </div>
//                     <div class="price">From $${service.price}</div>
//                     <div class="service-tags">
//                         ${service.tags.map(tag => `<span class="service-tag">${tag}</span>`).join('')}
//                     </div>
//                     <div class="service-card-footer">
//                         <span>Delivery: ${service.deliveryTime}</span>
//                         <button class="view-btn" data-service="${service.id}">View Details</button>
//                     </div>
//                 </div>
//             `;
//             trendingServicesContainer.appendChild(serviceCard);
//         });
//     }

//     // Populate testimonials
//     function renderTestimonials() {
//         testimonialSlider.innerHTML = '';
//         testimonials.forEach((testimonial, index) => {
//             const testimonialDiv = document.createElement('div');
//             testimonialDiv.className = `testimonial ${index === 0 ? 'active' : ''}`;
//             testimonialDiv.innerHTML = `
//                 <div class="client-info">
//                     <img src="${testimonial.avatar}" alt="${testimonial.name}">
//                     <div>
//                         <div class="client-name">${testimonial.name}</div>
//                         <div class="client-title">${testimonial.title}</div>
//                     </div>
//                 </div>
//                 <p class="testimonial-text">"${testimonial.text}"</p>
//                 <div class="rating-stars">
//                     ${'★'.repeat(testimonial.rating)}${'☆'.repeat(5 - testimonial.rating)}
//                 </div>
//             `;
//             testimonialSlider.appendChild(testimonialDiv);
//         });
//     }

//     // Testimonial slider functionality
//     let currentTestimonial = 0;
    
//     function showTestimonial(index) {
//         const testimonials = document.querySelectorAll('.testimonial');
//         testimonials.forEach(testimonial => testimonial.classList.remove('active'));
        
//         if (index >= testimonials.length) {
//             currentTestimonial = 0;
//         } else if (index < 0) {
//             currentTestimonial = testimonials.length - 1;
//         } else {
//             currentTestimonial = index;
//         }
        
//         testimonials[currentTestimonial].classList.add('active');
//     }
    
//     nextTestimonialBtn.addEventListener('click', () => {
//         showTestimonial(currentTestimonial + 1);
//     });
    
//     prevTestimonialBtn.addEventListener('click', () => {
//         showTestimonial(currentTestimonial - 1);
//     });

//     // Auto-rotate testimonials
//     setInterval(() => {
//         showTestimonial(currentTestimonial + 1);
//     }, 5000);

//     // Modal functionality
//     function openModal(serviceId) {
//         const service = trendingServices.find(s => s.id === parseInt(serviceId));
//         if (!service) return;
        
//         modalBody.innerHTML = `
//             <div class="service-details">
//                 <div class="service-details-header">
//                     <img src="${service.image}" alt="${service.title}">
//                     <div class="service-info">
//                         <h2>${service.title}</h2>
//                         <div class="service-seller">
//                             <img src="${service.seller.avatar}" alt="${service.seller.name}">
//                             <span>${service.seller.name}</span>
//                         </div>
//                         <div class="rating">
//                             ${'★'.repeat(service.seller.rating)}${'☆'.repeat(5 - service.seller.rating)}
//                             <span>(${service.seller.reviews} reviews)</span>
//                         </div>
//                         <div class="service-price">From $${service.price}</div>
//                         <div class="delivery-time">Delivery: ${service.deliveryTime}</div>
//                     </div>
//                 </div>
//                 <div class="service-description">
//                     <h3>About This Service</h3>
//                     <p>${service.description}</p>
//                 </div>
//                 <div class="service-features">
//                     <h3>What's Included</h3>
//                     <ul>
//                         <li>Professional ${service.category.replace('-', ' ')} service</li>
//                         <li>${service.deliveryTime} delivery time</li>
//                         <li>