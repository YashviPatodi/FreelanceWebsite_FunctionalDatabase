// Animation on scroll
const animateOnScroll = () => {
    const elements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });

    elements.forEach(element => {
        observer.observe(element);
    });
};

// Animated counter for stats
const animateCounters = () => {
    const counters = document.querySelectorAll('.stat-number');
    const speed = 200;
    
    counters.forEach(counter => {
        const target = counter.id === 'freelancers-count' ? 12500 :
                      counter.id === 'projects-count' ? 8400 :
                      counter.id === 'earnings-count' ? 3500000 :
                      counter.id === 'countries-count' ? 95 : 0;
        
        const count = () => {
            const current = +counter.innerText.replace(/\D/g, '');
            const increment = target / speed;
            
            if (current < target) {
                if (counter.id === 'earnings-count') {
                    counter.innerText = '$' + Math.ceil(current + increment).toLocaleString();
                } else {
                    counter.innerText = Math.ceil(current + increment).toLocaleString();
                }
                setTimeout(count, 1);
            } else {
                if (counter.id === 'earnings-count') {
                    counter.innerText = '$' + target.toLocaleString();
                } else {
                    counter.innerText = target.toLocaleString();
                }
            }
        };
        
        count();
    });
};

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    animateOnScroll();
    
    // Only animate counters when stats section is visible
    const statsObserver = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
            animateCounters();
            statsObserver.unobserve(entries[0].target);
        }
    });
    
    statsObserver.observe(document.querySelector('.stats-section'));
});