        // Dummy Projects Data
        const projects = [
            {
                id: 1,
                title: "E-commerce Website Development",
                description: "Need a developer to build a responsive e-commerce site using React and Node.js. Experience with payment gateways required.",
                budget: "$1,500 - $3,000",
                deadline: "Due in 3 weeks",
                skills: ["React", "Node.js", "MongoDB", "Stripe"],
                category: "web",
                image: "https://via.placeholder.com/350x180?text=E-commerce+Site"
            },
            {
                id: 2,
                title: "Mobile App UI/UX Design",
                description: "Looking for a talented designer to create modern UI/UX for a fitness tracking mobile app.",
                budget: "$800 - $1,200",
                deadline: "Due in 2 weeks",
                skills: ["Figma", "UI Design", "UX Design", "Mobile"],
                category: "design",
                image: "https://via.placeholder.com/350x180?text=Mobile+App+Design"
            },
            {
                id: 3,
                title: "Content Writing for Tech Blog",
                description: "Need a technical writer to create 10 articles about web development trends and technologies.",
                budget: "$500 - $800",
                deadline: "Due in 1 month",
                skills: ["Writing", "SEO", "Technical Writing", "Web Development"],
                category: "writing",
                image: "https://via.placeholder.com/350x180?text=Tech+Writing"
            },
            {
                id: 4,
                title: "Social Media Marketing",
                description: "Looking for a marketing specialist to manage our Instagram and LinkedIn accounts for 3 months.",
                budget: "$1,000 - $2,000",
                deadline: "Ongoing",
                skills: ["Social Media", "Marketing", "Content Creation", "Analytics"],
                category: "marketing",
                image: "https://via.placeholder.com/350x180?text=Social+Media"
            },
            {
                id: 5,
                title: "iOS App Development",
                description: "Need an experienced iOS developer to build a travel planning app with SwiftUI.",
                budget: "$2,500 - $4,000",
                deadline: "Due in 6 weeks",
                skills: ["Swift", "SwiftUI", "iOS", "Firebase"],
                category: "mobile",
                image: "https://via.placeholder.com/350x180?text=iOS+App"
            },
            {
                id: 6,
                title: "WordPress Website Redesign",
                description: "Looking for a WordPress developer to redesign our corporate website with a modern look.",
                budget: "$1,200 - $1,800",
                deadline: "Due in 4 weeks",
                skills: ["WordPress", "PHP", "CSS", "Elementor"],
                category: "web",
                image: "https://via.placeholder.com/350x180?text=WordPress"
            },
            {
                id: 7,
                title: "Data Analysis with Python",
                description: "Need a data analyst to process and visualize sales data using Python and Pandas.",
                budget: "$700 - $1,000",
                deadline: "Due in 2 weeks",
                skills: ["Python", "Pandas", "Data Visualization", "Excel"],
                category: "data",
                image: "https://via.placeholder.com/350x180?text=Data+Analysis"
            },
            {
                id: 8,
                title: "Logo and Branding Design",
                description: "Looking for a graphic designer to create a logo and brand identity for a new startup.",
                budget: "$300 - $600",
                deadline: "Due in 10 days",
                skills: ["Logo Design", "Branding", "Illustrator", "Photoshop"],
                category: "design",
                image: "https://via.placeholder.com/350x180?text=Logo+Design"
            },
            {
                id: 9,
                title: "SEO Optimization",
                description: "Need an SEO expert to optimize our website and improve search rankings.",
                budget: "$900 - $1,500",
                deadline: "Ongoing",
                skills: ["SEO", "Keyword Research", "Google Analytics", "Content"],
                category: "marketing",
                image: "https://via.placeholder.com/350x180?text=SEO"
            },
            {
                id: 10,
                title: "Android Game Development",
                description: "Looking for a Unity developer to create a simple 2D mobile game for Android.",
                budget: "$2,000 - $3,500",
                deadline: "Due in 8 weeks",
                skills: ["Unity", "C#", "Game Development", "Android"],
                category: "mobile",
                image: "https://via.placeholder.com/350x180?text=Mobile+Game"
            }
        ];

        // DOM Elements
        const projectsContainer = document.getElementById('projectsContainer');
        const registrationModal = document.getElementById('registrationModal');
        const registerBtn = document.getElementById('registerBtn');
        const closeModal = document.getElementById('closeModal');
        const registrationForm = document.getElementById('registrationForm');
        const skillsContainer = document.getElementById('skillsContainer');
        const skillInput = document.getElementById('skillInput');
        const addSkillBtn = document.getElementById('addSkillBtn');
        const portfolioUpload = document.getElementById('portfolioUpload');
        const portfolioFiles = document.getElementById('portfolioFiles');
        const aiAssistantBtn = document.getElementById('aiAssistantBtn');

        // Load projects
        function loadProjects() {
            projectsContainer.innerHTML = '';
            projects.forEach(project => {
                const projectCard = document.createElement('div');
                projectCard.className = 'project-card';
                projectCard.innerHTML = `
                    <div class="project-image" style="background-image: url('${project.image}')"></div>
                    <div class="project-content">
                        <h3 class="project-title">${project.title}</h3>
                        <p class="project-description">${project.description}</p>
                        <div class="project-meta">
                            <span class="project-budget">${project.budget}</span>
                            <span class="project-deadline">${project.deadline}</span>
                        </div>
                        <div class="project-skills">
                            ${project.skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
                        </div>
                        <div class="project-actions">
                            <button class="btn-apply">Apply Now</button>
                            <button class="btn-save"><i class="far fa-bookmark"></i> Save</button>
                        </div>
                    </div>
                `;
                projectsContainer.appendChild(projectCard);
            });
        }

        // Modal functionality
        registerBtn.addEventListener('click', () => {
            registrationModal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        });

        closeModal.addEventListener('click', () => {
            registrationModal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });

        window.addEventListener('click', (e) => {
            if (e.target === registrationModal) {
                registrationModal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });

        // Skills functionality
        function addSkill() {
            const skill = skillInput.value.trim();
            if (skill && !document.querySelector(`.skill-tag-input[data-skill="${skill}"]`)) {
                const skillTag = document.createElement('div');
                skillTag.className = 'skill-tag-input';
                skillTag.dataset.skill = skill;
                skillTag.innerHTML = `
                    ${skill}
                    <span class="remove-skill">&times;</span>
                `;
                skillsContainer.appendChild(skillTag);
                skillInput.value = '';
                
                // Add remove functionality
                skillTag.querySelector('.remove-skill').addEventListener('click', () => {
                    skillTag.remove();
                });
            }
        }

        addSkillBtn.addEventListener('click', addSkill);
        skillInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                addSkill();
            }
        });

        // Portfolio upload
        portfolioUpload.addEventListener('click', () => {
            portfolioFiles.click();
        });

        portfolioFiles.addEventListener('change', () => {
            if (portfolioFiles.files.length > 0) {
                portfolioUpload.innerHTML = `
                    <i class="fas fa-check-circle"></i>
                    <p>${portfolioFiles.files.length} file(s) selected</p>
                `;
            }
        });

        // Form validation
        registrationForm.addEventListener('submit', (e) => {
            e.preventDefault();
            let isValid = true;

            // Validate first name
            const firstName = document.getElementById('firstName');
            const firstNameError = document.getElementById('firstNameError');
            if (!firstName.value.trim()) {
                firstNameError.style.display = 'block';
                isValid = false;
            } else {
                firstNameError.style.display = 'none';
            }

            // Validate last name
            const lastName = document.getElementById('lastName');
            const lastNameError = document.getElementById('lastNameError');
            if (!lastName.value.trim()) {
                lastNameError.style.display = 'block';
                isValid = false;
            } else {
                lastNameError.style.display = 'none';
            }

            // Validate email
            const email = document.getElementById('email');
            const emailError = document.getElementById('emailError');
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value)) {
                emailError.style.display = 'block';
                isValid = false;
            } else {
                emailError.style.display = 'none';
            }

            // Validate password
            const password = document.getElementById('password');
            const passwordError = document.getElementById('passwordError');
            if (password.value.length < 8) {
                passwordError.style.display = 'block';
                isValid = false;
            } else {
                passwordError.style.display = 'none';
            }

            // Validate confirm password
            const confirmPassword = document.getElementById('confirmPassword');
            const confirmPasswordError = document.getElementById('confirmPasswordError');
            if (confirmPassword.value !== password.value) {
                confirmPasswordError.style.display = 'block';
                isValid = false;
            } else {
                confirmPasswordError.style.display = 'none';
            }

            // Validate country
            const country = document.getElementById('country');
            const countryError = document.getElementById('countryError');
            if (!country.value) {
                countryError.style.display = 'block';
                isValid = false;
            } else {
                countryError.style.display = 'none';
            }

            // Validate skills
            const skillsError = document.getElementById('skillsError');
            if (skillsContainer.children.length === 0) {
                skillsError.style.display = 'block';
                isValid = false;
            } else {
                skillsError.style.display = 'none';
            }

            // Validate bio
            const bio = document.getElementById('bio');
            const bioError = document.getElementById('bioError');
            if (!bio.value.trim()) {
                bioError.style.display = 'block';
                isValid = false;
            } else {
                bioError.style.display = 'none';
            }

            // Validate hourly rate
            const hourlyRate = document.getElementById('hourlyRate');
            const hourlyRateError = document.getElementById('hourlyRateError');
            if (!hourlyRate.value || parseFloat(hourlyRate.value) < 5) {
                hourlyRateError.style.display = 'block';
                isValid = false;
            } else {
                hourlyRateError.style.display = 'none';
            }

            // Validate terms
            const terms = document.getElementById('terms');
            const termsError = document.getElementById('termsError');
            if (!terms.checked) {
                termsError.style.display = 'block';
                isValid = false;
            } else {
                termsError.style.display = 'none';
            }

            if (isValid) {
                // Collect form values
                const formData = {
                    firstName: firstName.value,
                    lastName: lastName.value,
                    email: email.value,
                    password: password.value,
                    confirmPassword: confirmPassword.value,
                    country: country.value,
                    skills: Array.from(skillsContainer.children).map(tag => tag.dataset.skill),
                    bio: bio.value,
                    hourlyRate: hourlyRate.value,
                    termsAccepted: terms.checked
                };
            
                // Send to backend
                fetch("/submit-registration", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(formData)
                })
                .then(res => res.json())
                .then(data => {
                    alert(data.message || "Registration successful! Welcome to TheMetGig.");
                    registrationModal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                    registrationForm.reset();
                    skillsContainer.innerHTML = '';
                })
                .catch(err => {
                    console.error("❌ Error submitting registration:", err);
                    alert("❌ Registration failed. Please try again.");
                });
            }
            
        });

        // AI Assistant
        aiAssistantBtn.addEventListener('click', () => {
            alert('AI Assistant: How can I help you find the perfect freelance opportunity?');
        });

        // Initialize
        loadProjects();