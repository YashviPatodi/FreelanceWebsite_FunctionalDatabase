document.addEventListener('DOMContentLoaded', function() {
    const selector = document.querySelector('.floating-user-selector');
    const minimizeBtn = document.querySelector('.minimize-btn');
    const header = document.querySelector('.chat-header');
    
    function toggleMinimize() {
        selector.classList.toggle('minimized');
        minimizeBtn.textContent = selector.classList.contains('minimized') ? '+' : '−';
    }
    
    minimizeBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleMinimize();
    });
    
    header.addEventListener('click', function() {
        if (selector.classList.contains('minimized')) {
            toggleMinimize();
        }
    });
    
    document.querySelector('.freelancer-btn').addEventListener('click', function() {
        window.location.href = '/pages/freelancer.html';
    });
    
    document.querySelector('.client-btn').addEventListener('click', function() {
        window.location.href = '/pages/client.html';
    });
});