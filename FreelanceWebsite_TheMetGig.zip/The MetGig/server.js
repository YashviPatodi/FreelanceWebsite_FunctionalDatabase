const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Middlewares
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',        // your username
    password: 'Database12',        // your password, if any
    database: 'mywebsite'
});

db.connect((err) => {
    if (err) throw err;
    console.log('✅ Connected to MySQL!');
});

// Handle contact form submission
app.post('/submit-form', (req, res) => {
    const { name, email, subject, message } = req.body;
    const sql = 'INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)';
    db.query(sql, [name, email, subject, message], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send('❌ Error saving data.');
        }
        res.send('✅ Message saved successfully!');
    });
});

// ✅ Start the server after all routes
app.listen(port, () => {
    console.log(`🚀 Server running at http://localhost:${port}`);
});
